# L298 Motor Driver PCB
EAGLE files for L298 Dual H-Bridge Motor Driver Board. Also available at [OSH Park](https://oshpark.com/shared_projects/nI35iXkY).
